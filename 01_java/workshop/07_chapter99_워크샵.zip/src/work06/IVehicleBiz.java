package work06;

public interface IVehicleBiz {
	
	public Vehicle[] vehicleList();
	public void vehicleMove();
	public void vehicleAddFuel();
}
