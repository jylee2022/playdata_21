
public class TestPet {

	public static void main(String[] args) {

		Cat c = new Cat("야옹이", 2, "암컷");
		System.out.println(c.getInfo());
	}

}
