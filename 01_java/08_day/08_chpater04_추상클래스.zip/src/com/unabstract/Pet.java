package com.unabstract;

public class Pet {

	//변수
	//생성자
	
	//메서드
	// 공통적인 기능
	public void eat() {
		System.out.println("eat~");
	}
	
}
