package com.abstract2;

public class Cat extends Pet {

	@Override
	public void eat() {
		// TODO Auto-generated method stub

	}
	
}
