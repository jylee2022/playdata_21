package com.abstract2;

public class Dog extends Pet {

	@Override
	public void eat() {
		// TODO Auto-generated method stub

	}

}
