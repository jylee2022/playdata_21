package com.stu;

public class Student {

	public String name = "홍길동";
}
