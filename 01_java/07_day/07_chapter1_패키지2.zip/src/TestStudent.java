import com.stu.Student;


public class TestStudent {

	public static void main(String[] args) {

		Student s = new Student();
		
		com.stu2.Student s2 = 
				new com.stu2.Student();
	}

}
