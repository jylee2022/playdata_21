
public class TestPet {

	public static void main(String[] args) {

		Cat c = new Cat();
		
		
		
	}
}
