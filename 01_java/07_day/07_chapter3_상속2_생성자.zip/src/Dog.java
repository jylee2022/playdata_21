
public class Dog extends Pet{

	public Dog() {
		super();
	}

	
	
}
