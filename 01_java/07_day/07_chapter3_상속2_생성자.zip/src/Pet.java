
public class Pet {

	public Pet() {
		super(); // 명시적으로 삽입
		System.out.println("Pet 생성자");
	}
}
