
import com.stu.Student;

// default 패키지


public class TestStudent {

	public static void main(String[] args) {

		Student stu = new Student();
		//교수 생성하기

		com.professor.Professor p = 
				new  com.professor.Professor();
		
		com.professor.Professor p2 = 
				new  com.professor.Professor();
	}

}
