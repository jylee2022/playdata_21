import java.util.Scanner;

public class 문장2_제어문2_반복문2_while문2_무한루프 {

	public static void main(String[] args) {
		// 반복문
		/*
		 *  1. for문
		 *  
		 *   문법:
		 *     for(초기값 ; 조건식; 증감식 ){
		 *     
		 *     
		 *     }
		 *     
		 *     예> hello 문자열을 5번 출력하자.
		 *     
		 *       int n=1; //변수 초기화
		 *              "Hello" 출력
		 *       n++
		 *       n <= 5
		 *       
		 *       for(int n=1 ; n <= 5 ; n++ ){
		 *         System.out.println( "Hello" );
		 *       }
		 *       
		 *  2. while문
		 *   => 용도: 반복횟수 예측이 어려울 때 주로 사용됨.
		 *           무한루프에서 사용됨.
		 *  문법:
		 *  
		 *    초기값; 
		 *    while(조건식){
		 *       문장;
		 *       증감식;
		 *    }
		 *  
		 *  
		 *  3. do~ while문
		 * 
		 */
	  
		////////////////////////////////
		/*
		 *   무한루프 코드
		 *   
		 *   while(true){
		 *   
		 *   
		 *     if(무한루프에서 빠져나올조건식) break;
		 *   
		 *   }
		 * 
		 */
		////////////////////////////////
	
		 while(true) {
			 Scanner sc = new Scanner(System.in);
			 System.out.println("정수 입력하시오. 중지하려면 99 입력하시오");
			 int num = sc.nextInt();
			 //////////////////////////////
			 if(num==99)break;			
			 /////////////////////////////
			 System.out.println("입력값:"+ num);
		 }
		 
		 System.out.println("End");


	}//end main

}








