package com.loose;

public class NoSQLDAO implements DBDAO {

	@Override
	public void connect_db() {
	System.out.println("NoSQLDAO.connect_db");
	}

}
