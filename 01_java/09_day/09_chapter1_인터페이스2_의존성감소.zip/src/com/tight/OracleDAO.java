package com.tight;

public class OracleDAO {

	// 오라클 DB 연동하는 메서드
	public void oracle_connect() {
		System.out.println("OracleDAO.oracle_connect");
	}
	
	
}
