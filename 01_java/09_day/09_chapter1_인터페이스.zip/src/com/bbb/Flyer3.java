package com.bbb;

// 인터페이스간에는 다중 상속
public interface Flyer3 
extends Flyer, Flyer2 {

}
