package com.bbb;

public class Student {

}
