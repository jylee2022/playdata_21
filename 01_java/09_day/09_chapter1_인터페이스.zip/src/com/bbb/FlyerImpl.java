package com.bbb;


public class FlyerImpl 
extends Student 
implements Flyer, Flyer2 {

	@Override
	public void b() {

	}

	@Override
	public void a() {

	}
	
}
