 function fun2(){
   alert("alert 창");
}